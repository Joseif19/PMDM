package com.example.actividad4;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Vincular el botón con su ID en el XML
        Button miBoton = findViewById(R.id.miBoton);

        // Definir la acción al hacer clic en el botón
        miBoton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telefono = new Intent(Intent.ACTION_DIAL);
                telefono.setData(Uri.parse("tel:673883588"));
                startActivity(telefono);
            }
        });
    }
}
