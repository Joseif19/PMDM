package com.example.actividad6;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        String receivedString = getIntent().getStringExtra("cadena");
        double receivedDouble = getIntent().getDoubleExtra("decimal", 0.0);

        Toast.makeText(this, "Cadena: " + receivedString + ", Decimal: " + receivedDouble, Toast.LENGTH_SHORT).show();
    }
}
