package com.example.sumarrestar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText n1, n2;
    private CheckBox sumar, restar;
    private Button boton;
    private TextView texto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        n1 = findViewById(R.id.n1);
        n2 = findViewById(R.id.n2);
        sumar = findViewById(R.id.sumar);
        restar = findViewById(R.id.restar);
        boton = findViewById(R.id.boton);
        texto = findViewById(R.id.texto);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarOperacion();
            }
        });
    }

    private void realizarOperacion() {
        String texto1 = n1.getText().toString();
        String texto2 = n2.getText().toString();

        if (texto1.isEmpty() || texto2.isEmpty()) {
            Toast.makeText(this, "Introduce los dos números", Toast.LENGTH_LONG).show();
            return;
        }

        int n1 = Integer.parseInt(texto1);
        int n2 = Integer.parseInt(texto2);
        String resultado = "";

        if (sumar.isChecked()) {
            int suma = n1 + n2;
            resultado += "La suma es: " + suma + " ";
        }

        if (restar.isChecked()) {
            int resta;
            if(n1>n2) {
                resta = n1 - n2;
            }else{
                resta = n2 -  n1;
            }
            resultado += "La resta es: " + resta + " ";
        }

        if (!sumar.isChecked() && !restar.isChecked()) {
            Toast.makeText(this, "Seleccione al menos una operación", Toast.LENGTH_LONG).show();
            return;
        }

        texto.setText(resultado.toString());
    }
}