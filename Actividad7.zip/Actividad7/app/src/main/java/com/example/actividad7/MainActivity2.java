package com.example.actividad7;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity2 extends AppCompatActivity {
//    private static final int RESULT_OK = 1;  el result_ok predefinido tiene valor -1

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Button button = findViewById(R.id.button_return);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent devolver = new Intent();
                devolver.putExtra("resultKey", "Hola desde el MainActivity2");
                setResult(RESULT_OK, devolver);
                finish();
            }
        });
    }
}


